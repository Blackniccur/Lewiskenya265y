---
name: Trade animation wrapper structure
description: The animation__wrapper div was changed from a single flex row to a column layout to accommodate the risk disclaimer.
---

## Change made
`animation__wrapper` changed from `display:flex; align-items:center; height:40px` to `flex-direction:column; height:auto`.

An inner `animation__row` div (height:40px, display:flex) wraps the button + animation__container to preserve the original horizontal layout.

The `<p className='animation__risk-disclaimer'>` sits after `animation__row` inside `animation__wrapper`.

**Why:** The original wrapper was a single-line horizontal container. Adding a block-level disclaimer required converting the wrapper to a column layout with an inner row for the existing content.

**How to apply:** If the run-panel layout looks broken (button + progress bar stacking vertically), check that `animation__row` still wraps them both in trade-animation.tsx.
