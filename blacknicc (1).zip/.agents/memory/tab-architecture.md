---
name: Tab architecture
description: How the 9 main tabs are wired — constants, hash array, TAB_IDS, and lazy imports must all stay in sync.
---

## Rule
Any new tab requires changes in 4 places simultaneously:
1. `src/constants/bot-contents.ts` — add to `DBOT_TABS` and `TAB_IDS`
2. `src/pages/main/main.tsx` — update `hash` array (line ~89), add lazy import, add `<div label=...>` tab panel
3. Create the page component at `src/pages/<name>/index.tsx`
4. (Optional) Add route in `src/app/App.tsx` for standalone pages

## Current tab index map
- 0: Dashboard
- 1: Bot Builder
- 2: Chart
- 3: Tutorial
- 4: Free Bots
- 5: Analysis Tool (DCircles + Matches Tool sub-tabs)
- 6: Copy Trading
- 7: Classes
- 8: DTrader

**Why:** The `Tabs` component uses `active_index` (number) matched against the order of child `<div>` elements; the hash array maps index → URL hash for deep-linking. If these get out of sync the wrong tab activates on navigation.
