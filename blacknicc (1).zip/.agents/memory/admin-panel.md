---
name: Admin panel route
description: Secure admin panel for bot management, accessible at /admin with client-side password gate.
---

## Location
- Page: `src/pages/admin/index.tsx`
- Route: added as `<Route path='admin' ...>` in `src/app/App.tsx`

## Auth mechanism
- Password hashed with a simple `Math.imul` hash (not crypto-strength, client-side only)
- Hash stored in `localStorage` under key `mh_admin_hash`
- Default password: `mentorshub@admin2024`

## Bot storage
- Bots CRUD stored in `localStorage` under key `mh_admin_bots`
- Each bot: `{ id, name, description, category, xmlContent, visible, createdAt }`
- `visible: false` hides the bot from the Free Bots tab (Free Bots reads this key)

**Why:** No backend available; localStorage provides persistence. Admin panel is security-by-obscurity only — the route `/admin` is not linked from the main UI.
