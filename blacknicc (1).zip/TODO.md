# TODO

## Copy-trading signal alerts (alerts only)
- [x] Use Deriv's current public WebSocket tick endpoint for the signal and paper-simulation feed; it requires no OAuth token or app ID.
- [x] Add automated copy-trading signal detection that produces dashboard alerts only and never copies or submits orders.
- [x] Display each signal alert with essential context: instrument, direction or condition, timestamp, trigger details, and current status.

## V25 digit-7 Speedbot paper simulation
- [x] Integrate the existing V25 digit-7 DP Entry Point Speedbot preset into a clear start, pause, stop, and reset simulation workflow.
- [x] Run all Speedbot activity against a paper/simulation ledger only, including simulated entries, outcomes, balance changes, and performance totals.
- [x] Provide visible simulated activity history so users can review Speedbot runs and paper-ledger results without transactional broker actions.

## Existing dashboard and safety boundaries
- [x] Preserve the existing Black Niccur dashboard visual style, layout, and navigation while integrating the new functionality into the current app.
- [x] Exclude live order-copying, order submission, transactional endpoints, and broker/API token collection from the requested features.

## Manus WebDev deployment
- [x] Prepare the existing application for deployment on Manus WebDev with the required production configuration and build validation.
- [x] Present the exact public deployment content and intended Manus WebDev target for explicit user confirmation before publishing; the user chose to keep the preview only.
- [ ] After explicit approval, publish the latest checkpoint to the public Manus WebDev target and verify the successful live URL. The user explicitly declined publishing in this request.

## Branded preview startup
- [x] Replace the unbranded initial wait with a static QuoteX logo splash visible before the dashboard JavaScript opens.
- [x] Keep the QuoteX logo with React loading states while the dashboard continues initializing, then fade the splash away when the app takes over.
- [x] When secure account OAuth is unavailable, render the read-only preview without waiting for account API startup; keep the connected initialization path gated on OAuth readiness.
- [x] Keep this change preview-only; do not publish it publicly.

## QuoteX logo and Deriv setup
- [x] Use the supplied QuoteX FX Trader artwork as the header logo, startup splash, favicon, and WebDev project logo.
- [x] Match the displayed app name and page title to the supplied logo.
- [x] Treat the supplied alphanumeric identifier as an OAuth client ID, not as the legacy WebSocket `app_id`.
- [ ] Add account authentication using the supplied OAuth client ID through a secure server-side flow and a documented non-transactional trading-account scope. Blocked: current Deriv OAuth documentation lists no read-only trading-account scope (`application_read` reads registered apps; `trade` grants trading operations) and requires token exchange on a server. Leave login disabled and do not request `trade`.
- [x] Keep this request preview-only; do not publish the site publicly.

## Preview development connection
- [x] Configure Rsbuild HMR to use the browser-visible Preview origin instead of hard-coding `localhost:443`, which is not reachable through the Manus HTTPS preview proxy.

## Chart page resilience
- [x] When the Chart page unmounts before a Deriv account API is initialized, skip account-scoped tick cleanup safely instead of throwing while reading `forgetAll` from an absent API.
