# QuoteX FX Trader

A React/Rsbuild single-page trading dashboard based on the Deriv Bot project. It retains the uploaded charting, tutorials, Blockly Bot Builder, and DTrader screens, and adds two explicitly non-executing tools:

- **Copy-trading Signal Monitor:** observes public Deriv ticks and records reviewable alerts for the V25 (1s) digit-7 entry condition. It does not request a trader token or mirror an account.
- **V25 Speedbot Simulator:** models the uploaded DP Entry Point preset against a hypothetical browser-local paper ledger. The rule is last digit 7, then a one-tick Digit Over 2 paper result; default stake $5, +$100/−$100 session limits, and the preset's 2 × 0.7 next-stake progression after a loss. The illustrative payout model is not a forecast or offer; no broker order is submitted.

The **new signal and simulator screens** do not submit orders. The pre-existing Bot Builder and DTrader code remain separate and are not disabled by those screens.

## Requirements

- Node.js 24.x
- npm 11.19.0 (pinned in `package.json`)

## Deriv market data and account authentication

The Copy Trading Signal Monitor and Speedbot simulator use Deriv's current public WebSocket endpoint, `wss://api.derivws.com/trading/v1/options/ws/public`, with the `ticks` subscription; Deriv documents this public channel as requiring no authentication or app ID. The supplied alphanumeric identifier is an OAuth client ID, not a legacy WebSocket `app_id`.

Account login remains disabled in this static preview. Deriv's current OAuth guidance requires token exchange on a backend and an exactly registered HTTPS redirect URI. Its documented `application_read` scope is for registered applications, not trading-account data; its `trade` scope enables trading operations. The current docs do not list a read-only scope for trading-account authentication, so this app does not request `trade`, `account_manage`, or `payment`. Do not place OAuth secrets or access tokens in browser code or source control. No credentials are collected in chat. Google Drive save/load remains disabled unless its optional browser integration values are configured.

## Development

```bash
npm ci
npm run dev
```

The development server uses port `3000` and binds to `0.0.0.0` in the Manus Sandbox.

## Static build

```bash
npm run build
```

Rsbuild writes the static site to `dist/`; there is no server or database in this deployment. `npm run build` runs the brand CSS generator first. Manus WebDev is configured to install from the lockfile and build `dist/`.

## Branding

Update colors and typography in `brand.config.json`; `npm run generate:brand-css` bakes them into the theme CSS. The header app name also comes from `brand.config.json`. The supplied QuoteX logo is `public/logo.png` and is used in the header, splash, favicon, and WebDev project metadata.

## Data and limitations

Signal alerts, paper entries, and run summaries are kept in the current browser's local storage; they are not synchronized across devices. Signals and simulation advance only while the relevant page is open and its read-only tick connection is active. Historical sample frequencies are descriptive, not predictive. The simulated $1:1 net win/loss result is hypothetical and does not model real Deriv payouts, fees, or slippage.

## Third-party visitor scripts

The imported `index.html` retains its existing Google Tag Manager container (`GTM-KV9538TF`) and LiveChat widget (license `12049137`). Both load for visitors in a published build. Remove these embeds if you do not want the public site to load those third-party services.
