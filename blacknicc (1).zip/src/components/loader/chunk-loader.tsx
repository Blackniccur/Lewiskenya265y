import { Loader } from '@deriv-com/ui';
import { isPreviewMode, PREVIEW_BASE_PATH } from '@/utils/is-preview-mode';

const logoSrc = isPreviewMode() ? `${PREVIEW_BASE_PATH}/logo.png` : '/logo.png';

export default function ChunkLoader({ message }: { message: string }) {
    return (
        <div className='app-root' role='status' aria-live='polite'>
            <img className='app-root__logo' src={logoSrc} alt='' width='64' height='64' aria-hidden='true' />
            <Loader />
            <div className='load-message'>{message}</div>
        </div>
    );
}
